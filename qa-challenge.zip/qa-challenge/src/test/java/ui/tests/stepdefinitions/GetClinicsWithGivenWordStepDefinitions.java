package ui.tests.stepdefinitions;

import java.util.List;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import steps.GetClinicsWithGivenWordSteps;


public class GetClinicsWithGivenWordStepDefinitions {
	
	@Then("Verify Get Clinics With given word")
	public void verify_get_clinics_with_given_word(DataTable s) {
		
		List<List<String>> data = s.asLists();
		GetClinicsWithGivenWordSteps.getClinicsWithGivenWord(data.get(0).get(0));
	}

}
