package ui.tests.stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
//import utilities.BaseClass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Utilities.CommonMethods;

public class Hooks /*extends BaseClass*/ {


    @Before()
    public void beforeScenario(Scenario scenario) {


    }

    @AfterStep
    public void getScrShot(Scenario scenario) throws Exception {
    	
    }

    @After
    public void tearDown(Scenario scenario) throws IOException {

    	if(CommonMethods.driver!=null)
    	CommonMethods.driver.close();
        System.out.println("Driver is closed");

    }
}
