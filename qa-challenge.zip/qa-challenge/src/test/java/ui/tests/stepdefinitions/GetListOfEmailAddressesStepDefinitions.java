package ui.tests.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import steps.GetListOfEmailAddressesSteps;

public class GetListOfEmailAddressesStepDefinitions {
	
	
	@Given("generate Bearer Token")
	public void generate_bearer_token() {
		
		GetListOfEmailAddressesSteps.getBearerToken();
	    
	}
	
	@Then("verify get list of email addresses API")
	public void verify_get_list_of_email_addresses_api() {
		GetListOfEmailAddressesSteps.getListOfEmailAddresses();
	}


}
