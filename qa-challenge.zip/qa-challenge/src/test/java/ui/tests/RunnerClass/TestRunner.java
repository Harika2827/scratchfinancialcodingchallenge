package ui.tests.RunnerClass;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)

@CucumberOptions(features="src/test/resources",
				 glue= {"ui/tests/stepdefinitions"},
                /* tags = "@getClinicsWithGivenWord",	*/	
                 monochrome = true
)
public class TestRunner {
	
}
