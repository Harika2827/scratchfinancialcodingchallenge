package Utilities;

public class Config {

	public static String CURRENT_DIR = System.getProperty("user.dir");
	public static String chromeDriverPath = "D:\\Softwares\\chromedriver_win32\\chromedriver.exe"; 
}
