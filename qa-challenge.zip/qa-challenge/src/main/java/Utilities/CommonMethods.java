package Utilities;

import org.openqa.selenium.WebDriver;


public class CommonMethods {		
	
	public static WebDriver driver;
	
	
}
