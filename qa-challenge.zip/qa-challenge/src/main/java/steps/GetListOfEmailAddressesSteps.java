package steps;


import org.junit.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetListOfEmailAddressesSteps {
	
	static String authCode = "";
	
public static String getBearerToken() {		
		
		Response response = RestAssured.given()
				.header("Content-Type", "application/json")
				.param("email", "gianna@hightable.test")
				.param("password", "thedantonio1")
				.when()
				.get("https://qa-challenge-api.scratchpay.com/api/auth")
				.then()
				.assertThat().statusCode(200)
				.extract().response();

		if(response.getStatusCode()==200) {
			System.out.print("status code is 200");
			System.out.println("\n Response is " + response.body().asString());
			JsonPath j = new JsonPath(response.asString());
			authCode =	j.getString("data.session.token");
		//	authCode = response.jsonPath().get("ok");
			System.out.println("Authentication code- token value is--- " +authCode);	
		}	 else {
		System.out.print("status code is " + response.getStatusCode());
		System.out.println("Status is " + response.asString());
		}
		return authCode;
	}

public static Response getListOfEmailAddresses() {	
	
	if(authCode=="")
		authCode = getBearerToken();
	
	String errorMessageExpected = "";
	
	Response response = RestAssured.given()
			.header("Content-Type", "application/json")
			.header("Authorization", "Bearer " +authCode)
			.when()
			.get("https://qa-challenge-api.scratchpay.com/api/clinics/2/emails")
			.then()
			.assertThat().statusCode(400)
			.extract().response();
	JsonPath j = new JsonPath(response.asString());
	errorMessageExpected = j.getString("data.error");
	System.out.print(" error is " + errorMessageExpected);
	Assert.assertEquals(errorMessageExpected, "Error: User does not have permissions");
	Assert.assertTrue(errorMessageExpected, true);
	if(response.getStatusCode()==400) {
		System.out.print("status code is 400");
		System.out.println("\n Response is " + response.body().asString());	
	}	 else {
	System.out.print("status code is " + response.getStatusCode() + "Not displayed as expected");
	System.out.println("Status is " + response.asString());
	}
	return response;
}

	
}
