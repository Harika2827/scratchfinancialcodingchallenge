package steps;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetClinicsWithGivenWordSteps {
	
	static String authCode = "";
	
	public static void main (String[] s) {
		
		Response response = GetClinicsWithGivenWordSteps.getClinicsWithGivenWord("veterinary");
		
	}
	

public static Response getClinicsWithGivenWord(String word) {	
	
	if(authCode=="")
		authCode = GetListOfEmailAddressesSteps.getBearerToken();
	
	List<String> clinicNames = new ArrayList<String> ();
	
	Response response = RestAssured.given()
			.header("Content-Type", "application/json")
			.header("Authorization", "Bearer " +authCode)
			.when()
			.get("https://qa-challenge-api.scratchpay.com/api/clinics?term="+word+"")
			.then()
			.assertThat().statusCode(200)
			.extract().response();
	JsonPath j = response.jsonPath();//new JsonPath(response.asString());
	
	clinicNames = j.getList("data.displayName");

	// Iterate over the list and print individual book item
	for(String clinicName : clinicNames)
	{
	//	Assert.assertEquals(errorMessageExpected, "Error: User does not have permissions");
		if(clinicName.toLowerCase().contains(word.toLowerCase())) 
			System.out.print("As expected clinic name containing " + word + " displayed");
		else System.out.print("\n As expected clinic name containing " + word + " not displayed");
	}
	if(response.getStatusCode()==200) {
		System.out.print("status code is 200");
		System.out.println("\n Response is " + response.body().asString());	
	}	 else {
	System.out.print("status code is " + response.getStatusCode() + "Not displayed as expected");
	System.out.println("Status is " + response.asString());
	}
	return response;
}


	
}
